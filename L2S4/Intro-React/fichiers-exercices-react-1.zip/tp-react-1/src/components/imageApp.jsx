import React from 'react';

import '../assets/style/murImages.css';

import dataImages from '../data/dataImages.js';

/*
 define root component
*/
export default class ImageApp extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>Image App</div>
    );
  }
}
