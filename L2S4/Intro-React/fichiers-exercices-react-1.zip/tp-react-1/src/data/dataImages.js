const dataImages = [
    { image : "images/image0.jpg", texte : "la mer n'est pas contente" },
    { image : "images/image1.jpg", texte : "Ouch, ça mouille" } ,
    { image : "images/image2.jpg", texte : "la mer et les rochers" } ,
    { image : "images/image5.jpg", texte : "la plus belle...." } ,
    { image : "images/image7.jpg", texte : "Pas mal non plus celle-là" } ,
    { image : "images/image3.jpg", texte : "Grosse vague !" } ,
    { image : "images/image4.jpg", texte : "Chemin du littoral et arc-en-ciel avec une mer verte" },
    { image : "images/image6.jpg", texte : "Soleil sur la mer" },
    { image : "images/image9.jpg", texte : "le mont Saint-Michel derrière les herbes" } ,
    { image : "images/image10.jpg", texte : "le mont Saint-Michel dans la brume" } ,
    { image : "images/image11.jpg", texte : "le mont Saint-Michel et les dunes" } ,
    { image : "images/image12.jpg", texte : "le mont Saint-Michel" }
 ];

export default dataImages;
