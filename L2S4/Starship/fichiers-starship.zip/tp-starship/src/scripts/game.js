
class Game {

}


// crée et exporte l'instance unique de Game
const theGame = new Game();
export default theGame;
